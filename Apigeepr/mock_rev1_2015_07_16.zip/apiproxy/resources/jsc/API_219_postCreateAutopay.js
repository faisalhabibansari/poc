var objectId=context.getVariable("objectId");

context.setVariable('dataType', 'postCreateAutopay');

context.setVariable("objectId",objectId);