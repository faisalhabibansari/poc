var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType","SaveFollowUp");

var token = context.getVariable('request.header.token')

if(token=='gx0qdkdds32')
{
context.setVariable("objectId", "002");
}
else if(token=='fx00wmdlxw0'&& reqPayLoad.customerName!="John Smith")
{
context.setVariable("objectId", "002");
}
else if(token=='fx00wmdlxw0'&& reqPayLoad.customerName=="John Smith")
{
context.setVariable("objectId", "001");
}
