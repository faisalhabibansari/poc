 var sim = context.targetRequest.body.asJSON.SIM
var sim1 = context.getVariable("SIM");
var msidn = context.targetRequest.body.asJSON.msidn

if(sim=='1234567891011121314151' && sim1=='1234567891011121314151'){
  context.setVariable("objectId", "1234567891011121314151");
}else if(sim=='123454444011121314151' && sim1=='123454444011121314151'){
  context.setVariable("objectId", "123454444011121314151");
}
else if(
(msidn=='4254357654' && sim1=='1234567891234567801') || (msidn=='4254356547' && sim1=='1234567891234567801') || (msidn=='4251234567' && sim1=='1234567891234567801') || (msidn=='4254356547' && sim1=='1234567891234567815') || (msidn=='4254357654' && sim1=='1234567891234567815') || (msidn=='4251234567' && sim1=='1234567891234567815') || (msidn=='1111234567' && sim1=='1234567891234567801') || (msidn=='2061234568' && sim1=='1234567891234567801') || (msidn=='2061234569' && sim1=='1234567891234567801') ||  (msidn=='1111234567' && sim1=='1234567891234567801') ||  (msidn=='2061234567' && sim1=='1234567891234567801') || (msidn=='1111234567' && sim1=='1234567891234567815') || (msidn=='2061234567' && sim1=='1234567891234567815'))
  
{
  context.setVariable("objectId", "001");
}

else{
  context.setVariable("objectId", "");
}
