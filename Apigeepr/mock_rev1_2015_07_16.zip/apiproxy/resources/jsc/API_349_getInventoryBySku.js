var sku=context.getVariable("request.queryparam.sku");

context.setVariable("dataType",'deviceInventoryBySKU');

if(sku!=null)
{
context.setVariable("objectId",sku);
}
