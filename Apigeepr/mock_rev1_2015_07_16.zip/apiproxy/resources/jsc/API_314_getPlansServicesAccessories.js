var type=context.getVariable("request.queryparam.type");
var deviceId=context.getVariable("deviceId");
context.setVariable("dataType",'getPlansServicesAccessories');

if(deviceId=='134596' && (type==null || type=='')){
	context.setVariable("objectId","12345");
}

else if(deviceId=='134596' && type!=null && type!=''){
	context.setVariable("objectId","0001");
}
else if(deviceId=='Air134602' && (type==null || type=='')){
	context.setVariable("objectId","Air134602");
}else if(deviceId=='134602' && (type==null || type=='')){
	context.setVariable("objectId","134602");
}
else if(deviceId=='Sim134602' && (type==null || type=='')){
	context.setVariable("objectId","Sim134602");
}
else if(deviceId=='IP6' && (type==null || type=='')){
	context.setVariable("objectId","1001");
}
else if(deviceId=='3' && (type==null || type=='')){
	context.setVariable("objectId","1002");
}
else if(deviceId=='IPAD6' && (type==null || type=='')){
	context.setVariable("objectId","IPAD6");
}

