var UUINo=context.getVariable("UUINo");
context.setVariable("dataType",'AvayaContext');
context.setVariable("objectId",UUINo);

