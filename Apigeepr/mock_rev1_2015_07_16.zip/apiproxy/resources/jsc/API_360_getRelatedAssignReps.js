var objectId = context.getVariable("objectId");

context.setVariable("dataType",'getRelatedAssignReps');

context.setVariable("objectId","001");