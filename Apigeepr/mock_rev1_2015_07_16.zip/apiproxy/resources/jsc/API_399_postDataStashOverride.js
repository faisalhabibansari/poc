var reqPayLoad = context.targetRequest.body.asJSON
if(reqPayLoad!=null && reqPayLoad!='')
{
  context.setVariable("dataType",'postDataStashOverride');
  
 if(reqPayLoad.repId=='12345' && reqPayLoad.actionCode=='Add')
 {
   context.setVariable("objectId","001");
 }
 else
 {
  context.setVariable("objectId","000");
 }
}
else
{
  context.setVariable("objectId","000");
}