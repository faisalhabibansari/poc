var request_payload = '';
if(context.getVariable('request.content')!=null && context.getVariable('request.content')!='')
{
request_payload = JSON.parse(context.getVariable('request.content'));
}


if (request_payload.imei != null && request_payload.imei == '123456789'){
  
	context.setVariable("objectId", "001");
    context.setVariable("dataType", "tradeInEstimation");

}