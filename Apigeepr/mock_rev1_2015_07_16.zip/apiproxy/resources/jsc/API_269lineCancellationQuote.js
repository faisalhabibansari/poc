var reqPayLoad = context.targetRequest.body.asJSON
var customerId = context.getVariable("customerId");

if(customerId=='0123456789'){
  if(reqPayLoad!=null && reqPayLoad.accounts.length==1 && reqPayLoad.accounts[0].lines.length==2){
      if( reqPayLoad.accounts[0].id=='123123' && reqPayLoad.accounts[0].lines[0].id=='1111234567' && reqPayLoad.accounts[0].lines[1].id=='2221234567'){
          context.setVariable("objectId","001" );
      }
  }
  else if(reqPayLoad!=null && reqPayLoad.accounts.length==1 && reqPayLoad.accounts[0].lines.length==1){
      if(reqPayLoad!=null && reqPayLoad.accounts[0].id=='153153' && reqPayLoad.accounts[0].lines[0].id=='4441234567'){
          context.setVariable("objectId","002" );
      }else if(reqPayLoad!=null && reqPayLoad.accounts[0].id=='123123' && reqPayLoad.accounts[0].lines[0].id=='1111234567'){
          context.setVariable("objectId","003" );
      }else if(reqPayLoad!=null && reqPayLoad.accounts[0].id=='123123' && reqPayLoad.accounts[0].lines[0].id=='2221234567'){
          context.setVariable("objectId","004" );
      }else if(reqPayLoad!=null && reqPayLoad.accounts[0].id=='143143' && reqPayLoad.accounts[0].lines[0].id=='3331234567'){
          context.setVariable("objectId","005" );
      }else{
          context.setVariable("objectId", "");
      }
  }
  else if(reqPayLoad!=null && reqPayLoad.accounts.length==2){
    if(reqPayLoad.accounts[0].id=='123123' && reqPayLoad.accounts[0].lines[0].id=='1111234567' && reqPayLoad.accounts[1].lines[0].id=='3331234567'){
        context.setVariable("objectId","007" );
    }else if(reqPayLoad.accounts[0].id=='123123' && reqPayLoad.accounts[0].lines[0].id=='2221234567' && reqPayLoad.accounts[1].lines[0].id=='3331234567'){
        context.setVariable("objectId","008" );
    }
  }
}
else if(customerId=='9876543210'){
  if(reqPayLoad!=null && reqPayLoad.accounts[0].lines.length==1){
     if(reqPayLoad.accounts[0].id=='123123' && reqPayLoad.accounts[0].lines[0].id=='1111234567'){
          context.setVariable("objectId","006" );
      }
  }
}
else if(customerId=='0'){
   if(reqPayLoad!=null && reqPayLoad.accounts.length==1 && reqPayLoad.accounts[0].lines.length==1){
      if(reqPayLoad!=null && reqPayLoad.accounts[0].id=='123123' && reqPayLoad.accounts[0].lines[0].id=='2061234568'){
            context.setVariable("objectId","009" );
      }else if(reqPayLoad!=null && reqPayLoad.accounts[0].id=='123123' && reqPayLoad.accounts[0].lines[0].id=='2061234569'){
            context.setVariable("objectId","010" );
      }
   }
  
}
else{
      context.setVariable("objectId", "");
}
