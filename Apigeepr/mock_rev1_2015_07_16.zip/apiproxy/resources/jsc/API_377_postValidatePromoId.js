var reqPayLoad = context.targetRequest.body.asJSON
var cartId = reqPayLoad.cartId;
var promoId = reqPayLoad.promoId;
context.setVariable('dataType', 'postValidatePromoId');
if (reqPayLoad!=null && reqPayLoad!= '' && cartId=='1234' && promoId=='PROMO' ){
 context.setVariable("objectId", "001");
} 
else if (reqPayLoad!=null && reqPayLoad!= '' && cartId=='1506' && promoId=='FREESIM' ){
 context.setVariable("objectId", "002");
} 
else if (reqPayLoad!=null && reqPayLoad!= '' && cartId=='1507' && promoId=='TMOBILE20' ){
 context.setVariable("objectId", "003");
} 
else if (reqPayLoad!=null && reqPayLoad!= '' && cartId=='1506' && promoId=='TMOBILE10' ){
 context.setVariable("objectId", "004");
}
else if (reqPayLoad!=null && reqPayLoad!= '' && cartId=='1507' && promoId=='TMOBILESAVE30' ){
 context.setVariable("objectId", "005");
}
else if (reqPayLoad!=null && reqPayLoad!= '' && cartId=='1507' && promoId=='FREESIM' ){
 context.setVariable("objectId", "006");
}