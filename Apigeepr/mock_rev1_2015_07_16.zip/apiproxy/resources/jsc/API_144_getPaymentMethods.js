var paymentMethods=context.getVariable("request.queryparam.paymentMethods");
var id=context.getVariable("objectId");
var customerId=context.getVariable("customerId");
if(customerId=='425435' && paymentMethods=='storedPayments')
{
  context.setVariable("objectId","001");
}
else if(customerId=='425435' && paymentMethods=='failedPayments')
{
context.setVariable("objectId","002");
}
else if(customerId=='425435' && paymentMethods=='successfulPayments')
{
context.setVariable("objectId","003");
}
else if(customerId=='425435' && paymentMethods=='blockedPayments')
{
context.setVariable("objectId","004");
}
else if(customerId=='741852' && id=='123123789' && paymentMethods=='storedPayments')
{
context.setVariable("objectId","007");
}
else if(customerId=='741852' && id=='123123789' && paymentMethods=='failedPayments')
{
context.setVariable("objectId","008");
}
else if(customerId=='741852' && id=='123123789' && paymentMethods=='successfulPayments')
{
context.setVariable("objectId","009");
}
else if(customerId=='33337' && id=='55557')
{
context.setVariable("objectId","005");
}
else if(customerId=='44441' && id=='66661')
{
context.setVariable("objectId","006");
}
else {
  context.setVariable("objectId",id);
}
  