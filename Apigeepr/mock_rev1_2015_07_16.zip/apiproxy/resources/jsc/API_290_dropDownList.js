context.setVariable("dataType","dropDownList");
var type = context.proxyRequest.queryParams['type'];
var deviceManufacturer = context.proxyRequest.queryParams['deviceManufacturer'];

if(type=='customer'){
   	context.setVariable("objectId", "0001");
}else if(type=='order'){
 	context.setVariable("objectId", "0002");
}else if(type=='promotion'){
 	context.setVariable("objectId", "0003");
}else if(type=='deviceManufacturer'){
 	context.setVariable("objectId", "0004");
}else if(type=='deviceModels'){
  if (deviceManufacturer == 'Apple'){
 	context.setVariable("objectId", "0005");
  }else if (deviceManufacturer == 'Samsung'){
    context.setVariable("objectId", "0008");
  }
}else if(type=='customerSortBy'){
   context.setVariable("objectId", "0006");
}else if(type=='orderSortBy'){
   context.setVariable("objectId", "0007");
}
else if(type=='followup'){
   context.setVariable("objectId", "0009");
}
else if(type=='adjustment'){
   context.setVariable("objectId", "0010");
}
else if(type=='priceOverride'){
   context.setVariable("objectId", "0011");
}
else if(type=='paymentMethods'){
   context.setVariable("objectId", "0012");
}
else if(type=='paymentChannels'){
   context.setVariable("objectId", "0013");
}
else{
   context.setVariable("objectId", "0000");
}
