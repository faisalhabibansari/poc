var reqPayLoad = context.targetRequest.body.asJSON

var customerId=context.getVariable("customerId");
var accountId=context.getVariable("accountId");

context.setVariable("dataType","postRemoveStoredPaymentMethod");

if(reqPayLoad!=null)
{	
	if(customerId!=null && accountId!=null)
	{
      if(reqPayLoad.storedPaymentId=='xx3ixkk2n91')
      {
        context.setVariable("objectId","001");
      }
	}
    else
    {
       context.setVariable("objectId","000");
    }

} 