var reqPayLoad = context.targetRequest.body.asJSON

context.setVariable("dataType","postRepDashLog");

if(reqPayLoad!=null)
{	
	if(reqPayLoad.repId=='12412' && reqPayLoad.msisdn=='1235551234')
	{
        context.setVariable("objectId","001");
	}
    else if(reqPayLoad.repId=='JDaniel123' && reqPayLoad.msisdn=='5074385956')
    {
       context.setVariable("objectId","002");
    }
  else {
    context.setVariable("objectId","000");
    }
    } 