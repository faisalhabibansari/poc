var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType","VerifyConfirmationCode");
if(reqPayLoad.msisdn=='5551234567')
    { 
       	if(reqPayLoad.confirmationCode=='1122')
            {
                context.setVariable("objectId","001");
            }
        else if(reqPayLoad.confirmationCode=='3344')
            {
                context.setVariable("objectId","002");
            }
        else if(reqPayLoad.confirmationCode=='5566')
            {
                context.setVariable("objectId","003");
            }
    }