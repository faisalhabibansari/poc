var zipCode=context.getVariable("request.queryparam.zipCode"); 
context.setVariable('dataType', 'getCityStatebyZip');

 if(zipCode=='85281')
 {
   context.setVariable("objectId", "001");
 }
 else 
 {
   context.setVariable("objectId", "000");
 }   
  