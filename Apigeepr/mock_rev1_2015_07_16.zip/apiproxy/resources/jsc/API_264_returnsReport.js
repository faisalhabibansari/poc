if(context.proxyRequest.queryParams != null && context.proxyRequest.queryParams['storeId'] != null && context.proxyRequest.queryParams['date'] != null){
  var storeId=context.proxyRequest.queryParams['storeId'];
  var reportDate=context.proxyRequest.queryParams['date'];
  
  context.setVariable("dataType","returnsReport");
	if(storeId!='') {
		context.setVariable("objectId", storeId); 
	}
}