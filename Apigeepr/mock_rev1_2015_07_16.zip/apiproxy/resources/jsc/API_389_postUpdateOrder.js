var reqPayLoad = context.targetRequest.body.asJSON

var orderId=context.getVariable("objectId");

context.setVariable("dataType","postUpdateOrder");

if(reqPayLoad!=null)
{	
	if(orderId=='12121212' && reqPayLoad.requestId=='123123')
	{
        context.setVariable("objectId","001");
	}
  else if(orderId=='234236000' && reqPayLoad.requestId=='234236000'){
    context.setVariable("objectId","002");}
  else if(orderId=='234236001' && reqPayLoad.requestId=='234236001'){
    context.setVariable("objectId","003");}
} 