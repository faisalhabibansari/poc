var customerId=context.getVariable("customerId");
var accountId=context.getVariable("accountId");

context.setVariable("dataType","getTransactionHistory");
	
	/*if(customerId=='982333' && reqPayLoad.requestId=='123458899')
	{
        context.setVariable("objectId","001");
	}
   else if(customerId=='982564' && reqPayLoad.requestId=='123457788')
	{
        context.setVariable("objectId","002");
	} */
	
	if(customerId=='982333' && accountId=='123458899')
	{
        context.setVariable("objectId","003");
	}
	else if(customerId=='982564' && accountId=='123457788')
	{
        context.setVariable("objectId","004");
	}
    else
    {
     context.setVariable("objectId","000");
    }


