var reqPayLoad = context.targetRequest.body.asJSON
var cartId = reqPayLoad.cartId;

if(reqPayLoad!=null && reqPayLoad!= '')
{
 context.setVariable('dataType', 'postValidatePriceOverride');
 context.setVariable("objectId", cartId);
}
