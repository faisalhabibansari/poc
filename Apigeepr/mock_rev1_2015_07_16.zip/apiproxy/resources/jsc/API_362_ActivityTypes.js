//context.setVariable("objectId", "001");

var token = context.getVariable('request.header.token')

context.setVariable("dataType",'ActivityTypes');

if(token=='00x34frsdc' || token=='bx00fjwx00hkl')
{
context.setVariable("objectId", "002");
}
else
{
context.setVariable("objectId", "000");
}
