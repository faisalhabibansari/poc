//query parameter
var storeID=context.getVariable("request.queryparam.storeID");
var summarydate=context.getVariable("request.queryparam.date");

context.setVariable("dataType","dailyRegisterCashSummary");

if(storeID !=''){
  context.setVariable("objectId",storeID);
}