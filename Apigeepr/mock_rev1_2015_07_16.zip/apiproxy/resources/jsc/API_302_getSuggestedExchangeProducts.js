var orderID=context.getVariable("orderID");
var type=context.getVariable("request.queryparam.type");
var id=context.getVariable("request.queryparam.id");

context.setVariable("dataType",'getSuggestedExchangeProducts');

if(type=='device'&&id=='101')
{
 context.setVariable("objectId","101");
}
else if(type=='device'&&id=='102')
{
 context.setVariable("objectId","102");
}
else if(type=='device'&&id=='103')
{
 context.setVariable("objectId","103");
}
else if(type=='device'&&id=='104')
{
 context.setVariable("objectId","104");
}
else if(type=='device'&&id=='105')
{
 context.setVariable("objectId","105");
}
else if(type=='device'&&id=='120')
{
 context.setVariable("objectId","120");
}
else if(type=='Battery'&&id=='900')
{
 context.setVariable("objectId","900");
}
else if(type=='Battery'&&id=='902')
{
 context.setVariable("objectId","902");
}
else if(type=='Charger'&&id=='901')
{
 context.setVariable("objectId","901");
}
else if(type=='Charger'&&id=='903')
{
 context.setVariable("objectId","903");
}
else if(type=='Battery'&&id=='904')
{
 context.setVariable("objectId","904");
}
else if(type=='Charger'&&id=='905')
{
 context.setVariable("objectId","905");
}
else if(type=='device'&&id=='121')
{
 context.setVariable("objectId","121");
}
else if(type=='device'&&id=='122')
{
 context.setVariable("objectId","122");
}
else if(type=='Battery'&&id=='912')
{
 context.setVariable("objectId","912");
}
else if(type=='Charger'&&id=='913')
{
 context.setVariable("objectId","913");
}
else if(type=='Battery'&&id=='914')
{
 context.setVariable("objectId","914");
}
else if(type=='Charger'&&id=='915')
{
 context.setVariable("objectId","915");
}
else {
  context.setVariable("objectId",orderID);
}