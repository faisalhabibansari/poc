var installments = context.targetRequest.body.asJSON.installments;

if(installments != null)
{
  context.setVariable("objectId", "1133");
  context.setVariable("dataType","getPaymentArrangementOffer");
}
else
{
  context.setVariable("objectId", "1144");
  context.setVariable("dataType","getPaymentArrangementOffer");
}