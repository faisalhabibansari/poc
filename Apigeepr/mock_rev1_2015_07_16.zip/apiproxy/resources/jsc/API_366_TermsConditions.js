var reqPayLoad = context.targetRequest.body.asJSON
//var cartId = reqPayLoad.cartId;
var pageCategory = reqPayLoad.pageCategory;
var pageType = reqPayLoad.pageType
if(pageCategory =='cart' && pageType=='T&C'){

context.setVariable("dataType","TermsConditions");
context.setVariable("objectId","001");
}
