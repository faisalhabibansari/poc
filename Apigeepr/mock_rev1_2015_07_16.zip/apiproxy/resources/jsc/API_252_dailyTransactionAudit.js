//var storeId=context.getVariable("request.queryparam.storeId");
//var reportDate=context.getVariable("request.queryparam.date");

if(context.proxyRequest.queryParams != null && context.proxyRequest.queryParams['storeId'] != null && context.proxyRequest.queryParams['date'] != null){
  var storeId=context.proxyRequest.queryParams['storeId'];
  var reportDate=context.proxyRequest.queryParams['date'];
  
  context.setVariable("dataType","dailyTransactionAudit");
	if(storeId!='') {
		context.setVariable("objectId", storeId); 
	}
}