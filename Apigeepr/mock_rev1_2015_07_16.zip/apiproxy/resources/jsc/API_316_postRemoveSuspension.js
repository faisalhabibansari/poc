var reqPayLoad = context.targetRequest.body.asJSON

var customerId=context.getVariable("customerId");
var accountId=context.getVariable("accountId");

context.setVariable("dataType","postRemoveSuspension");

if(reqPayLoad!=null)
{	
	if(customerId!=null && accountId!=null)
	{
      if(reqPayLoad.imei=='0123456789012345' && reqPayLoad.msisdn=='3212524095')
      {
        context.setVariable("objectId","001");
      }
	}
    else
    {
       context.setVariable("objectId","000");
    }

} 