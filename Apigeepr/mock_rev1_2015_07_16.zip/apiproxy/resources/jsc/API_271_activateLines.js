var accountId=context.getVariable("accountId");
context.setVariable("dataType", "activateLines");

if(accountId=="7230223")
{
  context.setVariable("objectId","7230223" );
}
 
else if(accountId=="1530224")
{
  context.setVariable("objectId","1530224" );
}
else if(accountId=="7230113")
{
  context.setVariable("objectId","7230113" );
}
else if(accountId=="1530284")
{
  context.setVariable("objectId","1530284" );
}
  
 