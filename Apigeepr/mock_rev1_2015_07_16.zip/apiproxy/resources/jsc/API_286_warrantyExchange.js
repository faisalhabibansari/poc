var imei=context.getVariable("request.queryparam.imei");
context.setVariable("dataType","warrantyExchange");


if(imei!=null)
{
 context.setVariable("objectId",imei);
}