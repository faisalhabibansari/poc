context.setVariable("dataType","getAffiliates");

context.setVariable("objectId","001");

