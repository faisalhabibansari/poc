//var customerId = context.getVariable("customerId");
var accountId = context.getVariable("objectId");
var customerId = context.getVariable("customerId");


context.setVariable("dataType","getAutoPay");

if((accountId == '55555')|| (accountId == '55566'))
{
    if (customerId == '33347' && accountId == '55566') {
  		context.setVariable("objectId", "33347");
  	}
  	else {
		context.setVariable("objectId","55555");
  	}
}
else if((accountId == '55556') ||(accountId == '55565'))
{
  if (customerId == '33346' && accountId == '55565') {
   	context.setVariable("objectId", "33346"); 
  }
  
  else {
	context.setVariable("objectId","55556");
  }
}
else if(accountId == '55557')
{
context.setVariable("objectId","55557");
}
else if(accountId == '55558')
{
context.setVariable("objectId","55558");
}
else if(accountId == '55559')
{
context.setVariable("objectId","55559");
}
else if(accountId == '55560')
{
context.setVariable("objectId","55560");
}
else if(accountId == '55561')
{
context.setVariable("objectId","55561");
}
else if(accountId == '55562')
{
context.setVariable("objectId","55562");
}
else if(accountId == '55563')
{
context.setVariable("objectId","55563");
}
else if(accountId == '55564')
{
context.setVariable("objectId","55564");
}
else if(accountId == '123456678')
{
 context.setVariable("objectId", "123456678"); 
}