var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType","postEquipmentRefundRequest");
if(reqPayLoad!=null && reqPayLoad!='' && (reqPayLoad.refundType=='Mailed Refund card' || reqPayLoad.refundType=='BAN Refund' || reqPayLoad.refundType=='Electronic Check Payment' ))
{
context.setVariable("objectId","001");
}
   