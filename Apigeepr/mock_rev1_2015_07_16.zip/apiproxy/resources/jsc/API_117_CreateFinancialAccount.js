var reqPayLoad = context.targetRequest.body.asJSON;
var customerid = context.getVariable("customerId");
var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable('cid', customerid);
context.setVariable('dataType', 'CreateFinancialAccount');
if(reqPayLoad!=null)
{
  if(customerid=='500000015')
  {
	if(reqPayLoad.type=='postpaid')
		{
		context.setVariable("objectId", "007");
		}
	else if(reqPayLoad.type=='prepaid')
		{
		context.setVariable("objectId", "008");
		}
	else
		{
		context.setVariable("objectId", "500000003");
		}
  }
  else if(customerid=='500000001')
  {
	if(reqPayLoad.type=='postpaid')
		{
		context.setVariable("objectId", "001");
		}
	else if(reqPayLoad.type=='prepaid')
		{
		context.setVariable("objectId", "002");
		}
  }
   else if(customerid=='500000002')
  {
	if(reqPayLoad.type=='postpaid')
		{
		context.setVariable("objectId", "003");
		}
	else if(reqPayLoad.type=='prepaid')
		{
		context.setVariable("objectId", "004");
		}
  }
  else if(customerid=='500000011')
  {
	if(reqPayLoad.type=='postpaid')
		{
		context.setVariable("objectId", "005");
		}
	else if(reqPayLoad.type=='prepaid')
		{
		context.setVariable("objectId", "006");
		}
  }
  else if(customerid=='500000003')
  {
	if(reqPayLoad.type=='postpaid')
		{
		context.setVariable("objectId", "009");
		}
	else if(reqPayLoad.type=='prepaid')
		{
		context.setVariable("objectId", "010");
		}
  }
  else if(customerid=='741852')
  {
	if(reqPayLoad.type=='Prepaid')
		{
		context.setVariable("objectId", "011");
		}
	else if(reqPayLoad.type=='prepaid')
		{
		context.setVariable("objectId", "012");
		}
  }
  else 
  {
   context.setVariable("objectId", "234234");
  }   
}	