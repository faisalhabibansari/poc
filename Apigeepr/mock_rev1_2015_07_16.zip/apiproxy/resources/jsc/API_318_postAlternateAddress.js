var customerId=context.getVariable("customerId");
var accountId=context.getVariable("accountId");

var request_payload = '';
if(context.getVariable('request.content')!=null&&context.getVariable('request.content')!='')
{
request_payload = JSON.parse(context.getVariable('request.content'));
}

context.setVariable("dataType",'postAlternateAddress');

if(customerId=='12345'&&accountId=='67890'&&request_payload.alternateAddress!=null)
{
 context.setVariable("objectId","001");
}
