/*var lineId=context.getVariable("lineId");

if(lineId!=null)
{
  context.setVariable("objectId", lineId);
}

//var request_payload = JSON.parse(context.getVariable('request.content'));



if(request_payload.type=="911" && request_payload.address.line1!="")
{
  var lineId = context.getVariable("lineId");
  context.setVariable("objectId", lineId);
}
*/

var custId = context.getVariable("customerId");
var accId = context.getVariable("accountId");
var lineId = context.getVariable("lineId");

var reqPayload = context.targetRequest.body.asJSON
var address = reqPayload.address;
var line1 ;
if(address != null){
  line1 = address.line1;
}
var WifiCalling = reqPayload.WifiCalling;
context.setVariable("dataType","line");


if(reqPayload!=null && reqPayload!=''){
  
  if((line1==null || line1 == "") && custId=='234234235' && accId=='432432' && lineId=='4251234567'){
      if(WifiCalling==null || WifiCalling==''){
          context.setVariable("objectId", "12346");
      }else if(WifiCalling == true){
          context.setVariable("objectId", "12347");
      }else{
          context.setVariable("objectId", "");
      }
  }else if (line1 != '' && custId=='234234235' && accId=='432432' && lineId=='4251234567'){
      context.setVariable("objectId", "12345");  
  }else if(line1 != '' && custId=='1234567' && accId=='1330124' && lineId=='2162228888'){
      context.setVariable("objectId", "12348");  
  }else if(line1 != '' && custId=='1234569' && accId=='1330125' && lineId=='2162228889'){
      context.setVariable("objectId", "12349");  
  }else if(line1 != '' && custId=='1234570' && accId=='1330125' && lineId=='2162228889'){
      context.setVariable("objectId", "12350");  
  }else if(line1 != '' && custId=='1234566' && accId=='1230123' && lineId=='2062227777'){
      context.setVariable("objectId", "12351");  
  }else{
    context.setVariable("objectId", "");
  }
}else{
  context.setVariable("objectId", "");
}
