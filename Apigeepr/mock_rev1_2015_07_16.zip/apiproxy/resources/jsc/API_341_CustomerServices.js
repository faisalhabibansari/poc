var customerId =context.getVariable("customerId");
var accountId =context.getVariable("accountId");
context.setVariable("dataType",'CustomerServices');
if(customerId == '123456789' ||  accountId== '432432432')
{
  context.setVariable("objectId", "001")
}
else if(customerId == '1234' ||  accountId== '1234')
{
  context.setVariable("objectId", "002")
}
else if(customerId == '12345' ||  accountId== '12345')
{
  context.setVariable("objectId", "003")
}