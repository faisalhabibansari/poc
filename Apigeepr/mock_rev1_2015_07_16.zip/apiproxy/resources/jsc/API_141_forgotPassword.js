var loginName = context.getVariable("loginName");

var request_payload = '';
if(context.getVariable('request.content')!=null&&context.getVariable('request.content')!='')
{
request_payload = JSON.parse(context.getVariable('request.content'));
}


context.setVariable('dataType', 'forgotPassword');

if(JSON.stringify(request_payload).indexOf('"authentication-method-selected"')>=0&&JSON.stringify(request_payload).indexOf('"recovery-process"')>=0)
{
     if(JSON.stringify(request_payload).indexOf('"questions"')>=0)
     {
       context.setVariable("objectId", "questions");
     }
      
     else if(JSON.stringify(request_payload).indexOf('"text"')>=0)
     {
       context.setVariable("objectId", "text");
     }
  
     else if(JSON.stringify(request_payload).indexOf('"email"')>=0)
     {
       context.setVariable("objectId", "email");
     }
}
