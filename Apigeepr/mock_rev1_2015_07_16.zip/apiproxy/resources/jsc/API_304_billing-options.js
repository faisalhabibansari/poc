var customerID=context.getVariable("customerId");
var accountId=context.getVariable("accountId");
context.setVariable("dataType",'getBillingOptions');
if(customerID=='1234' &&accountId=='123123')
{
context.setVariable("objectId","001");
}
else if(customerID=='1234570' &&accountId=='123123')
{
context.setVariable("objectId","002");
}
else if(customerID=='1234570' &&accountId=='1234123')
{
context.setVariable("objectId","003");
}else if(customerID=='234234234' &&accountId=='9876543')
{
context.setVariable("objectId","004");
}else if(customerID=='234234235' &&accountId=='9876543')
{
context.setVariable("objectId","005");
}
else if(customerID=='761' &&accountId=='4000000606')
{
context.setVariable("objectId","006");
}
else if(customerID=='760' &&accountId=='4000000605')
{
context.setVariable("objectId","007");
}
else if(customerID=='756' &&accountId=='4000000601')
{
context.setVariable("objectId","008");
}