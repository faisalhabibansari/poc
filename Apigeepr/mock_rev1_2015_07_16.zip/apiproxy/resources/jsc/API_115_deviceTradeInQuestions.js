//Grabbing value of query param 'make' from URL

context.setVariable("queryParams",context.proxyRequest.queryParams);

if(context.proxyRequest.queryParams != '{}') { 
//&& context.proxyRequest.queryParams['make'] != null ){
  var make = context.proxyRequest.queryParams['make'];
    
  //var reMake = 'test';
  var makeLower = make.toLowerCase();
    if (makeLower=='apple') {
       context.setVariable('objectId', '0001');
     }
     else {
       context.setVariable('objectId', '0002');
    }
}

else{
  context.setVariable('objectId', '0003');
}


//Setting dataType
context.setVariable('dataType','deviceTradeInQuestions');