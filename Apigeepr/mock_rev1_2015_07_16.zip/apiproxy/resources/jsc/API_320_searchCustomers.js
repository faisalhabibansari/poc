var msisdn=context.getVariable("request.queryparam.msisdn");
var accntNo=context.getVariable("request.queryparam.accntNo");
var businessId=context.getVariable("request.queryparam.businessId");
var email=context.getVariable("request.queryparam.email");
var taxId=context.getVariable("request.queryparam.taxId");
var firstName=context.getVariable("request.queryparam.firstName");
var lastName=context.getVariable("request.queryparam.lastName");
var govtId=context.getVariable("request.queryparam.govtId");
var imei=context.getVariable("request.queryparam.imei");
var imsi=context.getVariable("request.queryparam.imsi");
var macId=context.getVariable("request.queryparam.macId");
var orderId=context.getVariable("request.queryparam.orderId");
var sim=context.getVariable("request.queryparam.sim");
var ssnLast4=context.getVariable("request.queryparam.ssnLast4");
var ssn=context.getVariable("request.queryparam.ssn");
var street=context.getVariable("request.queryparam.street");
var city=context.getVariable("request.queryparam.city");
var state=context.getVariable("request.queryparam.state");
var zip=context.getVariable("request.queryparam.zip");
var orderStartDate=context.getVariable("request.queryparam.orderStartDate");
var orderEndDate=context.getVariable("request.queryparam.orderEndDate");
var ccLast4=context.getVariable("request.queryparam.ccLast4");


var offset=context.getVariable("request.queryparam.offset");
var limit=context.getVariable("request.queryparam.limit");
var sort=context.getVariable("request.queryparam.sort");
var sortOrder=context.getVariable("request.queryparam.sortOrder");

var filter=context.getVariable("request.queryparam.filter");

if(email!=null && email!="")
{
email = email.toLowerCase();
}
if(firstName!=null && firstName!="")
{
firstName = firstName.toLowerCase();
}
if(lastName!=null && lastName!="")
{
lastName = lastName.toLowerCase();
}

 
context.setVariable("dataType","searchCustomers");

if(!(msisdn===undefined) && (msisdn=='2062345688'))
{
 context.setVariable("objectId","001");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc' && filter=='accStatus=open,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","060");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='desc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","061");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc' && filter=='accStatus=open,lineStatus=active,accType=individual,accSubType=postpaid')
{
 context.setVariable("objectId","062");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='desc' && filter=='accStatus=open,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","063");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=prepaid')
{
 context.setVariable("objectId","064");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=business,accSubType=all')
{
 context.setVariable("objectId","065");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","066");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=active,accType=all,accSubType=all')
{
 context.setVariable("objectId","067");
}
else if(msisdn=='4254357788' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","070");
}
else if(msisdn=='5074385956' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","102");
}
else if(!(accntNo===undefined) && (accntNo=='1234'))
{
 context.setVariable("objectId","002");
}
else if(businessId=='12mv')
{
 context.setVariable("objectId","003");
}
//else if(email=='adamstommy@domain.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc')
//{
 //context.setVariable("objectId","004");
//}
else if(email=='johnsmith@domain.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc')
{
 context.setVariable("objectId","032");
}
/*else if(email=='adamstommy@domain.com')
{
 context.setVariable("objectId","004");
}*/
else if(taxId=='0123')
{
 context.setVariable("objectId","005");
}
else if(firstName=='da' && lastName=='ma' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","088");
}
else if(firstName=='da' && lastName=='ma')
{
 context.setVariable("objectId","006");
}
else if(govtId=='13mca')
{
 context.setVariable("objectId","007");
}
else if(imsi=='123456978912321' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","068");
}
else if(imsi=='123456978912321' && offset=='10' && limit=='10' && sort=='msisdn' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","069");
}
else if(imei=='1234567887456321' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","072");
}
else if(imei=='12345678910112')
{
 context.setVariable("objectId","008");
}
else if(imsi=='123456978912321')
{
 context.setVariable("objectId","009");
}
else if(macId=='123456789-abcd-45')
{
 context.setVariable("objectId","010");
}
else if(orderId=='ABCD12345E')
{
 context.setVariable("objectId","011");
}
else if(!(sim===undefined) && (sim=='1234567891234561111'))
{
 context.setVariable("objectId","012");
}
else if(ssnLast4=='1234' && lastName=='adam')
{
 context.setVariable("objectId","013");
}
//else if(msisdn=='7788778606')
else if(msisdn=='7788778606' && offset==null && limit==null && sort==null && sortOrder==null)
{
 context.setVariable("objectId","014");
}
else if(email=='adams')
{
 context.setVariable("objectId","015");
}
else if(accntNo=='123456789')
{
 context.setVariable("objectId","016");
}
else if(businessId=='12mvd_0025')
{
 context.setVariable("objectId","017");
}
//else if(email=='adamstommy@domain.com')
//{
 //context.setVariable("objectId","018");
//}
else if(govtId=='13mca_0060')
{
 context.setVariable("objectId","019");
}
else if(orderId=='ABCD12345EFGH1234567891011121314')
{
 context.setVariable("objectId","020");
}
else if(ssn=='123456798')
{
 context.setVariable("objectId","021");
}
else if(taxId=='123456789')
{
 context.setVariable("objectId","022");
}
else if(imsi=='123456978912322')
{
 context.setVariable("objectId","023");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc')
{
 context.setVariable("objectId","024");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc'){
	context.setVariable("objectId","025");
}
else if(imsi=='123456978912321' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc')
{
 context.setVariable("objectId","026");
}
else if(imsi=='123456978912321' && offset=='10' && limit=='10' && sort=='msisdn' && sortOrder=='asc')
{
 context.setVariable("objectId","027");
}

else if(street=='221bBakerStreet' && city=='Marylebone' && state=='AL' && zip=='12345' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all'){
	context.setVariable("objectId","078");
}
else if(street=='221bBakerStreet' && city=='Marylebone' && state=='AL' && zip=='12345' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all'){
	context.setVariable("objectId","079");
}
else if(street=='221bBakerStreet' && city=='' && state=='' && zip=='' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all'){
	context.setVariable("objectId","080");
}
else if(street=='' && city=='' && state=='' && zip=='12345' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all'){
	context.setVariable("objectId","081");
}
else if(street=='' && city=='' && state=='AL' && zip=='' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all'){
	context.setVariable("objectId","082");
}
else if(street=='' && city=='Marylebone' && state=='' && zip=='' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all'){
	context.setVariable("objectId","083");
}
else if(street=='' && city=='' && state=='AL' && zip=='12345' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all'){
	context.setVariable("objectId","084");
}
else if(street=='' && city=='Marylebone' && state=='AL' && zip=='' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all'){
	context.setVariable("objectId","085");
}
else if(ccLast4=='0123' && orderStartDate=='04/19/2015' && orderEndDate=='05/19/2015' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all'){
	context.setVariable("objectId","086");
}
else if(ccLast4=='4567' && orderStartDate=='04/19/2004' && orderEndDate=='05/19/2006' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all'){
	context.setVariable("objectId","087");
}
else if(ssnLast4=='1234' && lastName=='Adams' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","089");
}

else if(street=='221bBakerStreet' && city=='Marylebone' && state=='AL' && zip=='12345'){
	context.setVariable("objectId","028");
}
else if(ssnLast4=='1234' && lastName=='Adams'){
	context.setVariable("objectId","029");
}
else if(ccLast4=='0123' && orderStartDate=='2015-05-19' && orderEndDate=='2015-06-19'){
	context.setVariable("objectId","030");
}
else if(msisdn=='2061239027' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc')
{
 context.setVariable("objectId","031");
}
else if(msisdn=='1111234567' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc')
{
 context.setVariable("objectId","033");
}
else if(ccLast4=='0123' && orderStartDate=='2015-04-19' && orderEndDate=='2015-05-19'){
    context.setVariable("objectId","034");
}
else if(ccLast4=='1234' && orderStartDate=='2012-04-15' && orderEndDate=='2015-05-15'){
    context.setVariable("objectId","034");
}
else if(ccLast4=='4567' && orderStartDate=='2004-04-19' && orderEndDate=='2006-05-19'){
    context.setVariable("objectId","034");
}
else if(street=='221bBakerStreet' && city=='' && state=='' && zip==''){
    context.setVariable("objectId","035");
}
else if(street=='' && city=='' && state=='' && zip=='12345'){
    context.setVariable("objectId","035");
}
else if(street=='' && city=='' && state=='AL' && zip==''){
    context.setVariable("objectId","035");
}
else if(street=='' && city=='Marylebone' && state=='' && zip==''){
    context.setVariable("objectId","035");
}
else if(street=='' && city=='' && state=='AL' && zip=='12345'){
    context.setVariable("objectId","035");
}
else if(street=='' && city=='Marylebone' && state=='AL' && zip==''){
    context.setVariable("objectId","035");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='accountId' && sortOrder=='asc')
{
 context.setVariable("objectId","036");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='accountId' && sortOrder=='desc')
{
 context.setVariable("objectId","037");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='accountStatus' && sortOrder=='asc')
{
 context.setVariable("objectId","038");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='accountStatus' && sortOrder=='desc')
{
 context.setVariable("objectId","039");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='accountSubType' && sortOrder=='asc')
{
 context.setVariable("objectId","040");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='accountSubType' && sortOrder=='desc')
{
 context.setVariable("objectId","041");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='accountType' && sortOrder=='asc')
{
 context.setVariable("objectId","042");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='accountType' && sortOrder=='desc')
{
 context.setVariable("objectId","043");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='desc')
{
 context.setVariable("objectId","045");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='lineStatus' && sortOrder=='asc')
{
 context.setVariable("objectId","046");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='lineStatus' && sortOrder=='desc')
{
 context.setVariable("objectId","047");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='desc')
{
 context.setVariable("objectId","048");
}
else if(email=='adamstommy@domain.com' && offset=='0' && limit=='10' && sort=='accountId' && sortOrder=='asc')
{
 context.setVariable("objectId","049");
}
else if(email=='adamstommy@domain.com'.toLowerCase() && offset=='0' && limit=='10' && sort=='accountId' && sortOrder=='desc')
{
 context.setVariable("objectId","050");
}
else if(email=='adamstommy@domain.com' && offset=='0' && limit=='10' && sort=='accountStatus' && sortOrder=='asc')
{
 context.setVariable("objectId","051");
}
else if(email=='adamstommy@domain.com' && offset=='0' && limit=='10' && sort=='accountStatus' && sortOrder=='desc')
{
 context.setVariable("objectId","052");
}
else if(email=='adamstommy@domain.com' && offset=='0' && limit=='10' && sort=='accountSubType' && sortOrder=='asc')
{
 context.setVariable("objectId","053");
}
else if(email=='adamstommy@domain.com' && offset=='0' && limit=='10' && sort=='accountSubType' && sortOrder=='desc')
{
 context.setVariable("objectId","054");
}
else if(email=='adamstommy@domain.com' && offset=='0' && limit=='10' && sort=='accountType' && sortOrder=='asc')
{
 context.setVariable("objectId","055");
}
else if(email=='adamstommy@domain.com' && offset=='0' && limit=='10' && sort=='accountType' && sortOrder=='desc')
{
 context.setVariable("objectId","056");
}
else if(email=='adamstommy@domain.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc')
{
 context.setVariable("objectId","057");
}
else if(email=='adamstommy@domain.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='desc')
{
 context.setVariable("objectId","058");
}
else if(email=='john.smith@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","059");
}
else if(email=='will.smith@gmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","071");
}
else if(email=='jeremy.son@gmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","073");
}
else if(email=='míckéy@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","074");
}
else if(email=='mi*@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","075");
}
else if(msisdn=='7788778*' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","076");
}
else if(firstName=='mike*' && lastName=='' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","077");
}
else if(email=='mi*123@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","090");
}
else if(firstName=='mik*' && lastName=='ab*' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","091");
}
else if(email=='mark.henry@gmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","094");
}
else if(email=='manish@mimomo.com'&& offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","095");
}
else if(email=='jesse@mimomo.com'&& offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","096");
}
else if(email=='maddy@mimomo.com'&& offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","097");
}
else if(email=='ray@mimomo.com'&& offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","098");
}
else if(email=='kayl@mimomo.com'&& offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","099");
}
else if(email=='johnsmith@mimomo.com'&& offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","101");
}
else if(email=='petersmith@gmail.com')
{
 context.setVariable("objectId","100");
}
//else if(email=='evin.martin@gmail.com')
  //{
 //context.setVariable("objectId","092");
//}
//else if(email=='mill.baker@gmail.com')
//{
 //context.setVariable("objectId","093");
//}
else
{
context.setVariable("objectId","000");
}