var imsi=context.getVariable("request.queryparam.imsi");
context.setVariable("dataType",'ImsiStatus');
if (imsi=='11234567890987654322')
{
context.setVariable("objectId", "002");
}
else
{
  context.setVariable("objectId", "001");
}