var msisdn = context.targetRequest.body.asJSON.msisdn
var customerId=context.getVariable("customerId");

context.setVariable("objectId", msisdn);