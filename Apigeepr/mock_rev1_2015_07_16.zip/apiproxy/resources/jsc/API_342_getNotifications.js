
var customerId=context.getVariable("customerId");

context.setVariable("dataType","getNotifications");
	
	if(customerId!=null )
	{
        context.setVariable("objectId","001");
	}
    else
    {
       context.setVariable("objectId","000");
    }
