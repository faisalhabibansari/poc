var customerID=context.getVariable("customerID");
var accountId=context.getVariable("accountId");
var amount=context.getVariable("request.queryparam.amount");
var days=context.getVariable("request.queryparam.days");
var serviceId=context.getVariable("request.queryparam.serviceId");

context.setVariable("dataType",'getServiceTax');

if(amount!=null)
{
  	if(days==null&&serviceId==null){
   		context.setVariable("objectId","001");
  	}
      if(amount == 15){
      		context.setVariable("objectId","003");
      } 
      else if(amount == 8.75){
      		context.setVariable("objectId","004");
      }
      else if(amount == 25){
      		context.setVariable("objectId","005");
      }
  		else if(amount == 28.45){
      		context.setVariable("objectId","006");
      }
}
else if(amount==null&&days!=null&&serviceId!=null)
{
context.setVariable("objectId","002");
}