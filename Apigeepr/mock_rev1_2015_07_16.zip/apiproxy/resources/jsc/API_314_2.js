var productOffertId = context.getVariable("request.queryparam.productOffertId")
context.setVariable("dataType",'API314_2');
if(productOffertId =='plan2522')
{
context.setVariable("objectId","001");
}
else if(productOffertId =='planAir2522'){
context.setVariable("objectId","002");
}
