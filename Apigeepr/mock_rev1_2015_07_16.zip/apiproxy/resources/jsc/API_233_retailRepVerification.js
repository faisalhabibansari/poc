var reqPayLoad = context.targetRequest.body.asJSON

if(reqPayLoad!=null)
{
    context.setVariable('dataType', 'retailRepVerification');
    
    if((reqPayLoad.username=='johnsmith@mimomo.com' && reqPayLoad.password=='S0perS&ve'))
    {  
      context.setVariable("objectId","1"); 
    }
    else if(reqPayLoad.username=='johnsmith@mimomo.com' && reqPayLoad.password=='S0pe')
    {  
      context.setVariable("objectId","2"); 
    }
    else if(reqPayLoad.firstName=='Katty' && reqPayLoad.lastInitial=='T' && reqPayLoad.dealerCode=='1234567' && reqPayLoad.tokenCode=='12345678' && reqPayLoad.passcode=='98765432')
	{
   		context.setVariable("objectId","3");
    }
  else if(reqPayLoad.username=='johnsmith@mimomo.com' && reqPayLoad.password=='S0perS&')
	{
   		context.setVariable("objectId","4");
    }
  else if(reqPayLoad.username=='johnsmith@mimomo.com' && reqPayLoad.password=='S0per')
	{
   		context.setVariable("objectId","5");
    }else{
      context.setVariable("objectId","000");
    }
}else{
  context.setVariable("objectId","000");
}