var customerID = context.getVariable("customerID");
var accountID = context.getVariable("accountID");
var msisdn = context.getVariable("lineID");
var deviceID = context.getVariable("deviceID");

var request_payload = '';
var questionAndAnswerResponse = {};
var flag =0;
if(context.getVariable('request.content')!=null&&context.getVariable('request.content')!='')
{
request_payload = JSON.parse(context.getVariable('request.content'));
  
questionAndAnswerResponse = request_payload.questionAndAnswerResponse;
if((questionAndAnswerResponse instanceof Array)&&questionAndAnswerResponse.length==4)
{
var q1 =questionAndAnswerResponse[0].questionId;
var a1 =questionAndAnswerResponse[0].answerId;
var q2 =questionAndAnswerResponse[1].questionId;
var a2 =questionAndAnswerResponse[1].answerId;
var q3 =questionAndAnswerResponse[2].questionId;
var a3 =questionAndAnswerResponse[2].answerId;
var q4 =questionAndAnswerResponse[3].questionId;
var a4 =questionAndAnswerResponse[3].answerId;
}

if(q1=='001'&&a1=='101'&&q2=='002'&&a2=='202'&&q3=='003'&&a3=='302'&&q4=='004'&&a4=='401')
{
  flag=1
} 
  
}

if(accountID=='123123'&& msisdn=='2061231234')
{
  context.setVariable("objectId",msisdn); // Case 1
}
else if(accountID=='123123'&& msisdn=='2061230066' && deviceID=='30')
{
     if(flag==1)
  {
     context.setVariable("objectId","206123006600");
  }
  else
  {
   context.setVariable("objectId",msisdn);
  }
}
else if((accountID=='123123'&& msisdn=='2061238566') || 
  		(accountID=='123123'&& msisdn=='2061233333'))
{
  if(flag==1)
    {
     context.setVariable("objectId","2061238566002");
  }
  else if(JSON.stringify(request_payload).indexOf('questionAndAnswerResponse')>=0)
    {
    context.setVariable("objectId","2061238566003");  // Case 3
    }
    else
    {
     context.setVariable("objectId","2061238566002"); // Case 2
    }
  
}

else if(accountID=='123123'&& msisdn=='2061239876')
{
  context.setVariable("objectId",msisdn);  // Case 4
}
else if(accountID=='123123'&& msisdn=='2061234321' || deviceID=='2' || deviceID=='3')
{
  context.setVariable("objectId",msisdn);  // Case 5
}
/*else if(accountID=='123123'&& msisdn=='2061236789')
{
  context.setVariable("objectId","2061236789006");  // Case 6
}*/
/*
else if(accountID=='123123'&& msisdn=='2061236789' && customerID=='1235')
{
  context.setVariable("objectId","2061236789010");  // Case 10
}*/
else if(accountID=='123123'&& msisdn=='2061236789' && (deviceID=='01' || deviceID=='9')||(customerID=='1239' && accountID=='123123'&& msisdn=='2061231111' || deviceID=='17' || deviceID=='18'))
{
  if(flag==1)
   {
     context.setVariable("objectId","2061236789011");
  }
  else
  {
  context.setVariable("objectId","2061236789010");  // Case 10
  }
}
/*else if(accountID=='123123'&& msisdn=='2061230000')
{
  context.setVariable("objectId","2061230000007");  // Case 7
}*/
else if((accountID=='123123'&& msisdn=='2061230000') && (deviceID=='01' || deviceID == '10'|| deviceID == '11' || deviceID == '12') )
{
   if(flag==1)
  {
     context.setVariable("objectId","2061230000010");
  }
  else
  {
  context.setVariable("objectId","2061230000009");  // Case 9
  }
}else if((accountID =='123123' && msisdn == '2061230011') && ( deviceID =='24' || deviceID =='25')){
  if(flag==1)
  {
   context.setVariable("objectId","206123001100");
  }
  else
  {
  context.setVariable("objectId","2061230011");  
  }
}
else if(accountID=='123123' && msisdn=='2061234567')
{
  context.setVariable("objectId",msisdn);  // Case 8
}
else if((customerID=='1234' && accountID =='123123'&& msisdn == '2061237482'&& deviceID =='15') || (customerID =='1202' && accountID =='123123'&& msisdn =='2061237482'&& deviceID == '15'))
{
    if(flag==1)
  {
  context.setVariable("objectId","206123748200");  
  }
  else
  {
  context.setVariable("objectId",msisdn);  // Case 11
  }
}
else if(customerID=='1238' && accountID =='123123'&& msisdn == '2061233333'&& deviceID =='20')
{
  context.setVariable("objectId",msisdn); 
}

/*else if((accountID =='123123'&& msisdn == '2061232222'&& deviceID =='19') ||
       (accountID =='123123'&& msisdn == '2061230022'&& deviceID =='26')  ||
  		(accountID =='123123'&& msisdn == '2061234444' && deviceID =='21')||
        (accountID =='123123'&& msisdn == '2061234444' && deviceID =='22')||
		(accountID =='123123'&& msisdn == '2061235555' && deviceID =='23')||
        (accountID=='123123' && msisdn=='2061232222' && deviceID=='19') ||
        (accountID=='123123' && msisdn=='2061230022' && deviceID=='26') ||
        (accountID=='123123' && msisdn=='2061235555' && deviceID=='23'))
  
{
  context.setVariable("objectId","2061231234");
}*/

else if((accountID =='123123' && msisdn == '2061232222' && deviceID =='19') ||
        (accountID =='123123' && msisdn == '2061234444' && deviceID =='21') ||
        (accountID =='123123' && msisdn == '2061234444' && deviceID =='22') ||
        (accountID =='123123' && msisdn == '2061235555' && deviceID =='23'))
  
{
  context.setVariable("objectId","2061231234");
}
else if((accountID =='123123'&& msisdn == '2061230022'&& deviceID =='26'))
{
 			context.setVariable("objectId",msisdn); 
}
else if((accountID =='123123'&& msisdn == '2061239000'&& deviceID =='31'))
{
  if(flag==1)
  {
  context.setVariable("objectId","206123900001");  
  }
  else
  {
 			context.setVariable("objectId",msisdn); 
  }
}
else if((accountID =='123123'&& msisdn == '2061239027'&& deviceID =='36'))
{
  	//Parsing out answers to questions
  if(flag==1)
  {
  context.setVariable("objectId","2061239027");  
  }else
  {
 	context.setVariable("objectId","20612390001");
  }
}

