var storeId=context.getVariable("request.queryparam.storeId");
var date=context.getVariable("request.queryparam.date");
var merchantId=context.getVariable("request.queryparam.merchantId");
if(merchantId=='POSR436'){
  context.setVariable("objectId", "POSR436");  
}else{
  context.setVariable("objectId", "000");  
}
context.setVariable("dataType","debitAndCreditReconciliation");



