var imei=context.getVariable("request.queryparam.imeiId");
context.setVariable("dataType",'DeviceUnlockCode')
if(imei==111)
{
 context.setVariable("objectId","111");
}
else if(imei==222)
{
context.setVariable("objectId","222");
}
