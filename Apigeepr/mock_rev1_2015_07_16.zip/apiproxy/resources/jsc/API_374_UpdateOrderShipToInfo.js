var reqPayLoad = context.targetRequest.body.asJSON
var objectId = context.getVariable("orderId");
context.setVariable("dataType","UpdateOrderShipToInfo");
if(reqPayLoad!=null && reqPayLoad!=''){
context.setVariable("objectId",objectId);
}
    else{
   context.setVariable("objectId","000");
    }