/*

Purpose: The script is aimed to retrieve mock object information from BaaS.

Developer: Chandan.Chawla@T-Mobile.com

Revisions:

6 April | Documentation Headers Added

*/

//Set data type for Baas object retrieval
context.setVariable("dataType","hostSystem");

//Grab query parameter corresponding to msisdn
var msisdn = context.getVariable("request.queryparam.msisdn");
                                 
if(msisdn!=null)
{  
  context.setVariable("objectId",msisdn);
}

//Grab query parameter corresponding to sim
var sim = context.getVariable("request.queryparam.sim");

if(sim!=null)
{  
  context.setVariable("objectId",sim);
}

//Grab query parameter corresponding to imsi
var imsi = context.getVariable("request.queryparam.imsi");

if(imsi!=null)
{  
  context.setVariable("objectId",imsi);
}