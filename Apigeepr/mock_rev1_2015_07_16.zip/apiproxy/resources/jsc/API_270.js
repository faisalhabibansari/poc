/*var reqPayLoad = context.targetRequest.body.asJSON;

var accountId = context.getVariable("accountId");

if(reqPayLoad!=null && reqPayLoad.MSISDN=='3212524095' && accountId=='20131010398547') { 
  
  context.setVariable("objectId", accountId);
  context.setVariable("dataType", "reportingLostStolenDevice");
}
*/


/*
var reqPayLoad = context.targetRequest.body.asJSON;

//var accountId = context.getVariable("accountId");

if(
 (reqPayLoad!=null && reqPayLoad.MSISDN=='4254356547') || (reqPayLoad!=null && reqPayLoad.MSISDN=='4254357654') || (reqPayLoad!=null && reqPayLoad.MSISDN=='4251234567') || (reqPayLoad!=null && reqPayLoad.MSISDN=='3212524095')||(reqPayLoad!=null && reqPayLoad.MSISDN=='2061234567')||(reqPayLoad!=null && reqPayLoad.MSISDN=='2061233333'))
{ 
  
  context.setVariable("objectId", '20131010398547');
  context.setVariable("dataType", "reportingLostStolenDevice");
}
*/

var reqPayLoad = context.targetRequest.body.asJSON;

context.setVariable("dataType", "reportingLostStolenDevice");

if(reqPayLoad!=null)
{
	var msisdn = reqPayLoad.MSISDN;

	if(msisdn=='1231231233' || msisdn=='1231231232' || msisdn=='1231231231' || msisdn=='4254356547' || msisdn=='4254357654' || msisdn=='4251234567' || msisdn=='3212524095' || msisdn=='2061234567' || msisdn=='2061233333')
	{
	context.setVariable("objectId", '20131010398547');
	}
}

