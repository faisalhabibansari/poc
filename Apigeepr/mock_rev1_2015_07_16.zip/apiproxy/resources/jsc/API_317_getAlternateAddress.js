var accountId=context.getVariable("accountId");
context.setVariable("objectId",accountId);
