//var q = context.proxyRequest.queryParams['q'];
//var advantage=context.getVariable("request.queryparam.advantage"); there is no such parameter as "advantage" - this was not in the spec
var companyName=context.getVariable("request.queryparam.companyName");
var offset=context.getVariable("request.queryparam.offset");
var limit=context.getVariable("request.queryparam.limit");
var sort=context.getVariable("request.queryparam.sort");
var sortOrder=context.getVariable("request.queryparam.sortOrder");

if(companyName!=null && companyName!="")
{
  companyName = companyName.toLowerCase();
}


if(companyName=='converse'&& offset=='10' && limit=='10' && sort=='state' && sortOrder=='asc' )
{
    context.setVariable("objectId", "0003");
}
else if(companyName=='converse'&& offset=='20' && limit=='10' && sort=='state' && sortOrder=='asc' )
{
    context.setVariable("objectId", "0004");
}
else if(companyName=='converse'&& offset=='0' && limit=='10' && sort=='state' && sortOrder=='asc' )
{
    context.setVariable("objectId", "0005");
}
else
{
 context.setVariable("objectId", "0000");
}
