var env = 'http://rebelliondev-dev01.apigee.net';

switch (process.env.env) {
  case 'dev02': env = 'http://rebelliondev-dev02.apigee.net'; break;
  case 'dev03': env = 'http://rebelliondev-dev03.apigee.net'; break;
  case 'test' : env = 'http://t-mobile-test.apigee.net'; break;
}

console.log('env ' + env);
var assert = require('chai').assert,
    expect = require('chai').expect,
	supertest = require('supertest'),
	facade = supertest(env);

var req = [{ "productId": "10001", "qty":1}];


 describe('POST', function() {
	it('respond JSON', function(done) {
		facade.post('/cchawla-web-cart/v1/customers/3000000036/cart')
		.send(req)
		.end(function(err, res) {
			if (err) throw err;
				assert(res.text!="");
				var resObj = JSON.parse(res.text);
				expect(resObj).to.have.property("id");
				expect(resObj).to.have.property("items");
				expect(resObj).to.have.property("accessories");
				expect(resObj).to.have.property("todayTotal");
				expect(resObj).to.have.property("montlyTotal");
				expect(resObj).to.have.property("promotions");
				expect(resObj).to.have.property("shipping");
			done();
			});
	});
   });



	describe('POST', function() {
	it('responds with Content-Type', function(done) {
		facade.post('/cchawla-web-cart/v1/customers/3000000036/cart')
		.send(req)
		.expect('Content-Type','application/json');
		done();
	});
   });

	describe('POST', function() {
	it('response with status 200', function(done) {
		facade.post('/cchawla-web-cart/v1/customers/3000000036/cart')
		.send(req)
		.end(function(err, res) {
			if (err) throw err;
			console.log('RES status: ' + res.status);
			assert(res.status == 200);
			done();
			});
	});
   });






