var env = '';
switch (process.env.env)
{
	case 'scossette':
		env = 'http://rebelliondev-dev01.apigee.net/scossette-web/v1';
		break;
	case 'sunny':
		env = 'http://rebelliondev-dev01.apigee.net/sunny-web/v1';
		break;
	case 'cchawla':
		env = 'http://rebelliondev-dev01.apigee.net/cchawla-web/v1';
		break;
	case 'dev01':
		env = 'http://rebelliondev-dev01.apigee.net/web/v1';
		break;
	case 'dev02':
		env = 'http://rebelliondev-dev02.apigee.net';
		break;
	case 'dev03':
		env = 'http://rebelliondev-dev03.apigee.net';
		break;
	case 'dit01':
		env = 'http://rebelliondev-dit01.apigee.net/web/v1';
		break;
}
var assert = require('chai').assert,
    expect = require('chai').expect,
	supertest = require('supertest'),
	facade = supertest(env);

console.log("env = "+env);


describe('Get MSSISDN Details', function() {
	it('/available-msisdn  : test for content properties', function(done) {
		console.log('Get available-msisdn for zipCode=98015');
		facade.get('/available-msisdn?zipCode=98015')
		.expect(200)
		.end(function(err, res) {
			if (err) throw err; 
			assert(res.text!="");
			var resObj = JSON.parse(res.text);			
			expect(resObj).to.have.property("availableMsisdns");
			expect(resObj.availableMsisdns[0]).to.have.property("areaCode"); 
			expect(resObj.availableMsisdns[0]).to.have.property("exchangeCode"); 
			expect(resObj.availableMsisdns[0]).to.have.property("city"); 
			done();
			});
	});
});


describe('Get MSSISDN Details', function() {
	it('/available-msisdn  : test for content values', function(done) {
		console.log('Get available-msisdn for zipCode=98015');
		facade.get('/available-msisdn?zipCode=98015')
		.expect(200)
		.end(function(err, res) {
			if (err) throw err; 
			assert(res.text!="");
			var resObj = JSON.parse(res.text);			
			expect(resObj).to.have.property("availableMsisdns");
			expect(resObj.availableMsisdns[0].areaCode).to.equal("[0-9]{3}"); 
			expect(resObj.availableMsisdns[0].exchangeCode).to.equal("[0-9]{3}"); 
			expect(resObj.availableMsisdns[0].city).to.equal("BELLEVUE");   
			done();
			});
	});
});


describe('Get MSSISDN Details', function() {
	it('/available-msisdn : test for status 200', function(done) {
		console.log('Get available-msisdn for zipCode=98015');
		facade.get('/available-msisdn?zipCode=98015')
		.end(function(err, res) {
			if (err) throw err;			
			assert(res.status == 200); 
			done();
			});
	});
});

describe('Get MSSISDN Details', function() {
	it('/available-msisdn : Test for missing zipCode', function(done) {
		console.log('zipCode is blank');
		facade.get('/available-msisdn?zipCode=""')
		.end(function(err, res) {			
			assert(res.status == 400); 
			done();
			});
	});
});

describe('Get MSSISDN Details', function() {
	it('/available-msisdn : Test for invalid zipCode', function(done) {
		console.log('zipCode is invalid, only Number is allowed');
		facade.get('/available-msisdn?zipCode=jsjkfhd')
		.end(function(err, res) {			
			assert(res.status == 400); 
			done();
			});
	});
});


describe('Get MSSISDN Details', function() {
	it('/available-msisdn  : test for content properties', function(done) {
		console.log('Get available-msisdn for areaCode=06 & exchangeCode=228');
		facade.get('/available-msisdn?areaCode=06&exchangeCode=228')
		.expect(200)
		.end(function(err, res) {
			if (err) throw err; 
			assert(res.text!="");
			var resObj = JSON.parse(res.text);			
			expect(resObj).to.have.property("msisdns");
			expect(resObj.msisdns[0]).to.equal("7706781234"); 
			expect(resObj.msisdns[1]).to.equal("7706781235"); 
			expect(resObj.msisdns[2]).to.equal("7706781236"); 
			expect(resObj.msisdns[3]).to.equal("7706781237"); 
			expect(resObj.msisdns[4]).to.equal("7706781238");   
			done();
			});
	});
});


describe('Get MSSISDN Details', function() {
	it('/available-msisdn : Test for invalid areaCode', function(done) {
		console.log('Invalid areaCode ,areaCode can contain nummeric value only.');
		facade.get('/available-msisdn?areaCode=0SDGH8&exchangeCode=228')
		.end(function(err, res) {			
			assert(res.status == 400); 
			done();
			});
	});
});


describe('Get MSSISDN Details', function() {
	it('/available-msisdn : Test for invalid exchange code', function(done) {
		console.log('Invalid exchange code ,exchange code can contain nummeric value only.');
		facade.get('/available-msisdn?areaCode=06&exchangeCode=22Jj8')
		.end(function(err, res) {			
			assert(res.status == 400); 
			done();
			});
	});
});

describe('Get MSSISDN Details', function() {
	it('/available-msisdn : Test for missing exchange code', function(done) {
		console.log('Missing exchange code.');
		facade.get('/available-msisdn?areaCode=06&exchangeCode=""')
		.end(function(err, res) {			
			assert(res.status == 400); 
			done();
			});
	});
});

describe('Get MSSISDN Details', function() {
	it('/available-msisdn : Test for missing areacode', function(done) {
		console.log('Missing areaCode.');
		facade.get('/available-msisdn?areaCode=""&exchangeCode=228')
		.end(function(err, res) {			
			assert(res.status == 400); 
			done();
			});
	});
});
