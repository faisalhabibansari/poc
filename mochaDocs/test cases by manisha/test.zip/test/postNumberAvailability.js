var env = '';
switch (process.env.env)
{
	case 'scossette':
		env = 'https://rebelliondev-dev01.apigee.net/scossette-web-self-service/v1';
		break;
	case 'cchawla':
		env = 'https://rebelliondev-dev01.apigee.net/cchawla-web-self-service/v1';
		break;
	case 'dev01':
		env = 'http://rebelliondev-dev01.apigee.net/khusboo-web/v1';
		break;
	case 'dev02':
		env = 'https://rebelliondev-dev02.apigee.net';
		break;
	case 'dev03':
		env = 'https://rebelliondev-dev03.apigee.net';
		break;
	case 'test':
		env = 'https://t-mobile-test.apigee.net';
		break;
	case 'testFacade':
		env = 'https://t-mobile-test.apigee.net/facade-api-1-x/v1';
		break;
	case 'dit01':
		env = 'http://rebelliondev-dit01.apigee.net/web-self-service/v1';
		break;
}

var assert = require('chai').assert,
	expect = require('chai').expect,
	supertest = require('supertest'),
	facade = supertest(env);
console.log("env = "+env);

var reqHeaders = {'Content-Type': 'application/json', 'senderid': 'TMO', 'channelid':'CARE', 'applicationid': 'CCO', 'transactionid':'bdcc74d8-b5b4-11e4-a71e-12e3f512a338', 'sessionid':'bdcc7866-b5b4-11e4-a71e-12e3f512a338', 'userid':'Mmugdal1','Accept':'application/json'}; 

// Valid  request payload
var req1 = {
    "type": "zipCode",
    "zipCode": [
        {
            "code": "98101",
            "limit": "1"
        },
        {
            "code": "98015",
            "limit": "1"
        }
    ]
};

	
// Request Payload with missing "zipCode" .
var req2 = {
    "type": "zipCode",
    "zipCode": [
        {
            "code": "",
            "limit": "1"
        },
        {
            "code": "",
            "limit": "1"
        }
    ]
};


//Request Payload with different limit value
var req3 = {
    "type": "zipCode",
    "zipCode": [
        {
            "code": "98101",
            "limit": "3"
        },
        {
            "code": "98015",
            "limit": "2"
        }
    ]
};


console.log("env = "+env);

describe('Post Number Availability- number validation', function() {
	it('/general-info/number-availability : test for content properties', function(done) {
		console.log('Number Availability');
		facade.post('/mobile-number/availability')
		.set(reqHeaders)
		.send(req1)
		.end(function(err, res) {
			if (err) throw err;
			assert(res.text!="");
			var resObj = JSON.parse(res.text);
			
			console.log("resObj = "+ JSON.stringify(resObj));
			expect(resObj).to.have.property("availableMobileNumber");
			expect(resObj).to.have.property("mobileNumber");
			expect(resObj.mobileNumber).to.have.property("zipcode");
			expect(resObj.mobileNumber).to.have.property("msisdn");
			done();
			});
	});
});


describe('Post Number Availability- number validation', function() {
	it('/general-info/number-availability : test for missing input values ', function(done) {
		console.log('Number Availability');
		facade.post('/mobile-number/availability')
		.set(reqHeaders)
		.send(req2)
		.end(function(err, res) {
			assert(res.status == 400);
			done();
			});
	});
});

describe('Post Number Availability- number validation', function() {
	it('/general-info/number-availability : test for content values ', function(done) {
		console.log('Number Availability');
		facade.post('/mobile-number/availability')
		.set(reqHeaders)
		.send(req3)
		.end(function(err, res) {
			if (err) throw err;
			assert(res.text!="");
			var resObj = JSON.parse(res.text);
			expect(resObj.availableMobileNumber.mobileNumber[0].zipcode).to.equal("98101");
			expect(resObj.availableMobileNumber.mobileNumber[0].msisdn).to.equal("2063381111");
			done();
			});
	});
});

describe('Post Number Availability- number validation', function() {
	it('/general-info/number-availability : response with status 200', function(done) {
		console.log('Number Availability');
		facade.post('/mobile-number/availability')
		.send(req1)
		.end(function(err, res) {
			if (err) throw err;			
			assert(res.status == 200);
			done();
			});
	});
});