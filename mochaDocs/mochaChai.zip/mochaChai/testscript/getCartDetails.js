var env = 'http://rebelliondev-dev01.apigee.net';

switch (process.env.env) {
  case 'dev02': env = 'http://rebelliondev-dev02.apigee.net'; break;
  case 'dev03': env = 'http://rebelliondev-dev03.apigee.net'; break;
  case 'test' : env = 'http://t-mobile-test.apigee.net'; break;
}

console.log('env ' + env);
var assert = require('chai').assert,
	supertest = require('supertest'),
	facade = supertest(env);




describe('GET', function() {
	it('responds with JSON', function(done) {
		facade.get('/cchawla-web-cart/v1/customers/3000000036/cart/021B5BC9A0CF4B20AFCCC606EF9B1076')
		.expect(200)
		.end(function(err, res) {
			var resObj = JSON.parse(res.text);
			console.log('RES: ' + resObj.id);
			// if (err) throw err;
			assert(resObj.id == "123565765675665");
			// assert(res.body.value == 25);
			done();
			});
	});
});


// describe('GET', function() {
// 	console.log('11111111111');
// 	it('responds with JSON', function(done) {
// 		console.log('22222222222');
// 		// console.log(facade);
// 		facade.get('http://rebelliondev-dev01.apigee.net/cchawla-web-cart/v1/customers/3000000036/cart/021B5BC9A0CF4B20AFCCC606EF9B1076', function (res)
// 		{
//         console.log('333333333');
// 	    done();
// 		});
// 		done();
// 	});
// });

/*
describe('GET', function() {
	it('responds with Content-Type', function(done) {
		facade.get('/cchawla-web-cart/v1/customers/3000000036/cart/021B5BC9A0CF4B20AFCCC606EF9B1076')
		.expect('Content-Type','application/json');
		done();
	});
});
describe('GET', function() {
	it('responds with response data', function(done) {
		facade.get('/cchawla-web-cart/v1/customers/3000000036/cart/021B5BC9A0CF4B20AFCCC606EF9B1076')
		.expect(200);
		done();
	});
});
describe('GET', function() {
	it('responds with JSON', function(done) {
		console.log('Start');
		facade.get('/cchawla-web-cart/v1/customers/3000000036/cart/021B5BC9A0CF4B20AFCCC606EF9B1076')
		.expect('Content-Type','application/json')
		.expect(200)
		.end(function(err, res) {
			console.log(res);
			done();
		});
		done();
	});
});
*/
 /* it("should display input text from a form.", function(done){
        request.post('localhost:8080')
            .send({field: "Test string."})
            .end(function(res){
                expect(res).to.exist;
                expect(res.status).to.equal(200);
                expect(res.text).to.contain("Test");
                done();
        });
            	});

*/