var supertest = require('supertest-as-promised'),
    agent = supertest.agent('http://www.w3schools.com'),
    api = supertest('http://t-mobile-test.apigee.net'),
    mockapi = supertest('http://localhost:5000'); 

describe('GET', function() {
	it('responds with JSON', function(done) {
		agent.get('/website/Customers_JSON.php')
		.expect('Content-Type','text/html; charset=UTF-8')
		.expect(200, done)
	});
});

describe('GET', function() {
	it('responds with JSON', function(done) {
		api.get('/facade-api-poc/people')
		.expect('Content-Length','1686')
		.expect(200, done)
	});
});

describe('Post', function() {
	it('post & responds with JSON', function(done) {
		var testuser = {
			name : 'testuser'
		};
		
		mockapi.get('/user')
		.expect(200)
		.then(function(res){
			console.log("in");
			mockapi.post('/userData').send(testuser)
			.expect('Content-Type', /json/)
			.expect(200)
			.end(function(err, res) {
				if (err) throw err;
				done();
				});
		})
	});
});










