var env = 'http://rebelliondev-dev01.apigee.net';

switch (process.env.env) {
  case 'dev02': env = 'http://rebelliondev-dev02.apigee.net'; break;
  case 'dev03': env = 'http://rebelliondev-dev03.apigee.net'; break;
  case 'test' : env = 'http://t-mobile-test.apigee.net'; break;
}

console.log('env ' + env);
var assert = require('chai').assert,
    expect = require('chai').expect,
	supertest = require('supertest'),
	facade = supertest(env);


var jsonRequest = {
    "eipBalance": 100,
    "questionAndAnswerResponse": {
        "questionId": 2,
        "answerId": 1
    }
}
 


 describe('POST', function() {
	it('respond JSON', function(done) {
		facade.post('/cchawla-web-customer/v1/customers/3000000026/accounts/178664782/lines/4251230090/devices/123654789101254/quote-and-fulfillment')
		.send(jsonRequest)
		.end(function(err, res) {
			if (err) throw err;
			assert(res.text!="");
			var resObj = JSON.parse(res.text);
			expect(resObj).to.have.property("quoteId");
			expect(resObj).to.have.property("claimRequired");
			expect(resObj).to.have.property("jumpTradeInValue");
			done();
			});
	});
   });



	describe('POST', function() {
	it('responds with Content-Type', function(done) {
		facade.post('/cchawla-web-customer/v1/customers/3000000026/accounts/178664782/lines/4251230090/devices/123654789101254/quote-and-fulfillment')
		.send(jsonRequest)
		.expect('Content-Type','application/json');
		 done();
	});
   });

	describe('POST', function() {
	it('response with status 200', function(done) {
		facade.post('/cchawla-web-customer/v1/customers/3000000026/accounts/178664782/lines/4251230090/devices/123654789101254/quote-and-fulfillment')
		.send(jsonRequest)
		.end(function(err, res) {
			if (err) throw err;
			console.log('RES status: ' + res.status);
			assert(res.status == 200);
			done();
			});
	});
   });