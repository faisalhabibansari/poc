var env = 'http://rebelliondev-dev01.apigee.net';

switch (process.env.env) {
  case 'dev02': env = 'http://rebelliondev-dev02.apigee.net'; break;
  case 'dev03': env = 'http://rebelliondev-dev03.apigee.net'; break;
  case 'test' : env = 'http://t-mobile-test.apigee.net'; break;
}

console.log('env ' + env);
var assert = require('chai').assert,
	expect = require('chai').expect,
	supertest = require('supertest'),
	facade = supertest(env);



describe('GET', function() {
	it('responds with JSON', function(done) {
		facade.get('/cchawla-web-customer/v1/customers/3000000146/line-authorization')
		.expect(200)
		.end(function(err, res) {
			if (err) throw err;
			    assert(res.text!="");
		    	var resObj = JSON.parse(res.text);
		    	expect(resObj).to.have.property("numberOfEligibleLines");
			    expect(resObj).to.have.property("depositAmount");
			    expect(resObj).to.have.property("creditCheckRequired");
			    done();
			});
	});
});

describe('GET', function() {
	it('responds with Content-Type', function(done) {
		facade.get('/cchawla-web-customer/v1/customers/3000000146/line-authorization')
		.expect('Content-Type','application/json');
		done();
	});
});


describe('GET', function() {
	it('response with status 200', function(done) {
		facade.get('/cchawla-web-customer/v1/customers/3000000146/line-authorization')
		.end(function(err, res) {
			if (err) throw err;
			console.log('RES status: ' + res.status);
			assert(res.status == 200);
			done();
			});
	});
});